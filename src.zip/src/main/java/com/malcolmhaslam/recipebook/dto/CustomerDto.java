package com.malcolmhaslam.recipebook.dto;

import lombok.Data;

import java.util.Set;

@Data
public class CustomerDto {
    private Long id;
    private String name;
}
